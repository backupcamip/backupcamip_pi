#!/bin/bash
# version 1.1
# Kills process if it has been running too long. default is > 600 seconds or 10 minutes
# Suggest you run this script from a crontab every 5 minutes or so.  
# Add appropriate line to crontab using command sudo crontab -e
# example crontab entry below without # comment char
# */5 * * * * /home/pi/sync.sh >/dev/nul


echo "$0 version 1.3" 
# Get current folder where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"


# check if gdrive is already running to avoid multiple instances
if [ -z "$(pgrep backupcamip)" ]
  then
    
      # Run gdrive for files in folder specified by variable $SYNC_DIR
      echo "---------------------- PROCESSING ---------------------------------"
      echo "Found sync lock file $DIR/$SYNC_FILE"
      echo "Starting Push google drive subfolder"
      echo "-------------------------------------------------------------------"     
      cd $DIR
      echo "Start synchronization ....."
      echo "sudo /usr/bin/"
      /usr/bin/backupcamip
      # Check if gdrive exited successfully
      if [ $? -ne 0 ]
      then
        echo "ERROR - backupcamip Processing failed."
        echo "Possible Cause - No internet connection or some other reason see dev/nul log file"
      else
        # If successful 
        echo "SUCCESS - $0 Processing completed successfully"
       
      fi
    cd $DIR
else
  # bckip is already running so check how long and kill if past time limit
  if [ -z "$(sudo ps axh -O etimes | grep backupcamip | grep -v grep | sed 's/^ *//'| awk '{if ($2 >= 600) print $1}')" ]
  then
    RUNTIME=$(sudo ps axh -O etimes | grep backupcamip | grep -v grep | sed 's/^ *//' | awk '{if ($2 > 0) print $2}' | head -1)
    echo "Another Sync already running for "$RUNTIME" seconds."
    echo "Will kill if greater than 600 seconds."
  else
    GDRIVEPID=$(pgrep backupcamip)
    echo "gdrive has run longer than 600 seconds so kill PID $GDRIVEPID"
    KILLPID=$(ps axh -O etimes | grep backupcamip | grep -v grep | awk '{if ($2 >= 600) print $1}')
    echo "Killing $KILLPID"
    sudo kill $KILLPID
  fi  
fi
echo "Done"
exit
